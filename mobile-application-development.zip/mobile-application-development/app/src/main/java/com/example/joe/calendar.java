package com.example.joe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class calendar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);
    }
}